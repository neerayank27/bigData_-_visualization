async function loadData() {
    const res = await fetch("/api/summary");
    return await res.json();
}

function formatCurrency(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
    if (num >= 1000) return (num / 1000).toFixed(0) + "K";
    return num;
}

function histogram(values, bins = 10) {
    if (values.length === 0) return { labels: [], counts: [] };
    
    const min = Math.min(...values);
    const max = Math.max(...values);
    const step = (max - min) / bins;

    let labels = [], counts = Array(bins).fill(0);

    values.forEach(v => {
        let i = Math.floor((v - min) / step);
        if (i >= bins) i = bins - 1;
        counts[i]++;
    });

    for (let i = 0; i < bins; i++) {
        let start = min + i * step;
        let end = min + (i + 1) * step;
        labels.push(`${formatCurrency(start)} - ${formatCurrency(end)}`);
    }

    return { labels, counts };
}

async function render() {
    const data = await loadData();

    document.getElementById("total").innerText = data.total_listings.toLocaleString();
    document.getElementById("avg").innerText = "Rs " + formatCurrency(data.average_price);
    document.getElementById("median").innerText = "Rs " + formatCurrency(data.median_price);

    // Filter valid positive prices for charts
    const validRecords = data.records.filter(r => r.price > 0);
    const prices = validRecords.map(r => r.price);
    const hist = histogram(prices);

    const commonOptions = {
        responsive: true,
        plugins: {
            legend: { labels: { color: '#2c3e50', font: { family: "'Segoe UI', sans-serif" } } }
        },
        scales: {
            x: { 
                ticks: { color: '#7f8c8d' }, 
                grid: { color: '#ecf0f1' } 
            },
            y: { 
                ticks: { color: '#7f8c8d' }, 
                grid: { color: '#ecf0f1' } 
            }
        }
    };

    new Chart(histChart, {
        type: "bar",
        data: {
            labels: hist.labels,
            datasets: [{
                label: 'Number of Listings',
                data: hist.counts,
                backgroundColor: 'rgba(52, 152, 219, 0.7)',
                borderColor: '#3498db',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            ...commonOptions,
            plugins: { ...commonOptions.plugins, legend: { display: false } }
        }
    });

    new Chart(scatterChart, {
        type: "scatter",
        data: {
            datasets: [{
                label: 'Price vs Age',
                data: validRecords.map(r => ({ x: r.age, y: r.price })),
                backgroundColor: 'rgba(41, 128, 185, 0.6)',
                borderColor: '#2980b9'
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    title: { display: true, text: 'Vehicle Age (Years)', color: '#7f8c8d' },
                    ticks: { color: '#7f8c8d' },
                    grid: { color: '#ecf0f1' }
                },
                y: {
                    title: { display: true, text: 'Price (Rs)', color: '#7f8c8d' },
                    ticks: { callback: function(value) { return formatCurrency(value); }, color: '#7f8c8d' },
                    grid: { color: '#ecf0f1' }
                }
            }
        }
    });

    new Chart(brandChart, {
        type: "bar",
        data: {
            labels: Object.keys(data.avg_price_by_brand),
            datasets: [{
                label: 'Average Price',
                data: Object.values(data.avg_price_by_brand),
                backgroundColor: 'rgba(46, 204, 113, 0.7)',
                borderColor: '#2ecc71',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    ticks: { callback: function(value) { return formatCurrency(value); }, color: '#7f8c8d' },
                    grid: { color: '#ecf0f1' }
                },
                x: {
                   ticks: { color: '#7f8c8d' },
                   grid: { display: false }
                }
            },
            plugins: { ...commonOptions.plugins, legend: { display: false } }
        }
    });

    const tbody = document.querySelector("#dataTable tbody");
    tbody.innerHTML = ""; // Clear existing rows
    data.records.forEach(r => {
        tbody.innerHTML += `
            <tr>
                <td><strong>${r.brand}</strong></td>
                <td>${r.model}</td>
                <td>${r.yom}</td>
                <td>${r.age} yrs</td>
                <td>${r.mileage.toLocaleString()} km</td>
                <td><strong>Rs ${r.price.toLocaleString()}</strong></td>
            </tr>`;
    });
}

render();
