Prerequisites
1.  **Python 3.8+**
2.  **Apache Kafka** (running in KRaft mode)

Installation

1.  Install Dependencies
    ```bash
    pip install -r requirements.txt
    ```

2.  Start Kafka (KRaft Mode)


    ```bash
    <!-- ``Generate Cluster ID (Only once) -->
    kafka-storage.bat random-uuid

    <!-- Folder path:  -->
    cd C:\kafka_2.13-4.1.1

    <!-- Format Storage Directory (replace <uuid> with generated ID) -->
    kafka-storage.bat format -t <uuid> -c config/server.properties

    <!-- Start Kafka Server -->
    kafka-server-start.bat config/server.properties
    ```

3.  **Create Kafka Topics**

    ```bash
    kafka-topics.bat --create --topic car.raw.prices --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
    kafka-topics.bat --create --topic car.cleaned.prices --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
    ```

4. **How to Run the Pipeline**

    Terminal 1: Create Database
    ```bash
    <!-- python db/create_db.py -->
    ```

    Terminal 2: Analytics Consumer (Saves to DB)
    ```bash
    <!-- python consumer/analytics_consumer.py -->
    ```

    Terminal 3: Alert Consumer (Real-time monitoring)
    ```bash
    <!-- python consumer/alert_consumer.py -->
    ```

    Terminal 4: Web Dashboard
    ```bash
    <!-- python dashboard/app.py -->
    ```
     Access the dashboard at http://127.0.0.1:5000

    Terminal 5: Start Stream Processor
    ```bash
    <!-- python transformer/stream_processor.py -->
    ```

    Terminal 6: Start Data Producer
    ```bash
    <!-- python producer/producer.py -->
    ```

    Terminal 7: Start Statistics Monitor
    ```bash
    <!-- python consumer/stats_consumer.py -->
    ```