import json, time, logging
import pandas as pd
from kafka import KafkaProducer
import sys
import os

# Add parent directory to path to import scraper module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scraper.car_scraper import scrape_car_data

logging.basicConfig(
    filename="pipeline.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Configuration
NUM_PAGES_TO_SCRAPE = 5  # Number of pages to scrape from ikman.lk
SCRAPE_DELAY = 1  # Delay between requests (seconds)

def load_data():
    try:
        print("=" * 60)
        print("STARTING WEB SCRAPING MODE")
        print("=" * 60)
        logging.info("Starting web scraping mode")
        
        # Scrape data from ikman.lk
        raw_df = scrape_car_data(num_pages=NUM_PAGES_TO_SCRAPE, delay=SCRAPE_DELAY)
        
        if raw_df.empty:
            logging.warning("Scraping returned no data.")
            print("\nNo data scraped.")
            return pd.DataFrame()
        
        print(f"\n✓ Successfully loaded {len(raw_df)} records from web scraping")
        logging.info(f"Successfully loaded {len(raw_df)} records from web scraping")
        return raw_df
        
    except Exception as e:
        logging.error(f"Error during web scraping: {e}")
        print(f"\n✗ Error during web scraping: {e}")
        return pd.DataFrame()

def main():
    print("\n" + "=" * 60)
    print("KAFKA PRODUCER - RAW CAR DATA STREAMING")
    print("=" * 60)
    
    # Load data
    df = load_data()
    
    # Initialize Kafka producer
    try:
        producer = KafkaProducer(
            bootstrap_servers="localhost:9092",
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        print("\n✓ Connected to Kafka broker")
        logging.info("Connected to Kafka broker")
    except Exception as e:
        logging.error(f"Failed to connect to Kafka: {e}")
        print(f"\n✗ Failed to connect to Kafka: {e}")
        print("Please ensure Kafka is running on localhost:9092")
        sys.exit(1)
    
    topic_name = "car.raw.prices"
    print("\n" + "=" * 60)
    print(f"PRODUCING EVENTS TO KAFKA TOPIC: {topic_name}")
    print("=" * 60)
    
    # Send events to Kafka
    success_count = 0
    error_count = 0
    
    for idx, row in df.iterrows():
        try:
            # Convert row to dict, handling NaN values
            event = row.where(pd.notnull(row), None).to_dict()
            
            producer.send(topic_name, value=event)
            success_count += 1
            
            # Print a brief summary of the event (limit output)
            brand = event.get('Brand', event.get('brand', 'Unknown'))
            model = event.get('Model', event.get('model', 'Unknown'))
            price = event.get('Price', event.get('price', 'Unknown'))
            
            print(f"[{idx + 1}/{len(df)}] Produced: {brand} {model} - {price}")
            logging.info(f"Produced event: {event}")
            
            time.sleep(1)  # Delay between messages
            
        except Exception as e:
            error_count += 1
            logging.error(f"Error producing event for row {idx}: {e}")
            print(f"✗ Error producing event for row {idx}: {e}")
    
    # Flush and close
    producer.flush()
    producer.close()
    
    print("\n" + "=" * 60)
    print("PRODUCTION SUMMARY")
    print("=" * 60)
    print(f"✓ Successfully produced: {success_count} events")
    if error_count > 0:
        print(f"✗ Failed: {error_count} events")
    print("=" * 60)
    
    logging.info(f"Production completed. Success: {success_count}, Errors: {error_count}")

if __name__ == "__main__":
    main()
