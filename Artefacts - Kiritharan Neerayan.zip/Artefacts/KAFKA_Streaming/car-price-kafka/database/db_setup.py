import sqlite3

conn = sqlite3.connect("car_stream.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS car_prices (
    vehicle_id TEXT,
    brand TEXT,
    model TEXT,
    yom INTEGER,
    vehice_age INTEGER,
    engine_cc INTEGER,
    mileage INTEGER,
    price INTEGER,
    date TEXT
)
""")

conn.commit()
conn.close()

print("Database ready with all columns.")
