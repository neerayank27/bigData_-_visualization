from kafka import KafkaConsumer
import json
import sqlite3

consumer = KafkaConsumer(
    "car.cleaned.prices",
    bootstrap_servers="localhost:9092",
    auto_offset_reset="earliest",
    group_id="analytics-group",
    value_deserializer=lambda x: json.loads(x.decode("utf-8"))
)

conn = sqlite3.connect("car_stream.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS car_prices (
    vehicle_id TEXT,
    brand TEXT,
    model TEXT,
    yom INTEGER,
    vehice_age INTEGER,
    engine_cc INTEGER,
    mileage INTEGER,
    price INTEGER,
    date TEXT
)
""")
conn.commit()

print("Analytics consumer running...")

for msg in consumer:
    data = msg.value

    cursor.execute("""
        INSERT INTO car_prices VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data["vehicle_id"],
        data["brand"],
        data["model"],
        data["yom"],
        data["vehice_age"],
        data["engine_cc"],
        data["mileage"],
        data["price"],
        data["date"]
    ))

    conn.commit()
    print("Consumed:", data)
