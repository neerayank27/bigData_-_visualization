import os
import json
from datetime import datetime
from kafka import KafkaConsumer

# Setup alert logging
ALERT_LOG_FILE = "alerts.log"

def log_alert(alert_data):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {alert_data['level']}: {alert_data['message']} | Vehicle: {alert_data['vehicle']}\n"
    
    with open(ALERT_LOG_FILE, "a") as f:
        f.write(log_entry)

consumer = KafkaConsumer(
    "car.cleaned.prices",
    bootstrap_servers="localhost:9092",
    group_id="alert-group",
    value_deserializer=lambda x: json.loads(x.decode("utf-8"))
)

print("\n" + "="*50)
print("REAL-TIME ALERT SYSTEM ACTIVE")
print("="*50)

for msg in consumer:
    data = msg.value
    price = data["price"]
    brand = data["brand"]
    model = data["model"]
    vehicle_info = f"{brand} {model} ({data['yom']})"
    
    alert = None
    
    if price > 10000000:
        alert = {
            "level": "HIGH_VALUE",
            "message": f"Premium Vehicle Detected: Rs {price:,}",
            "vehicle": vehicle_info
        }
        # Red for High Price
        print(f"\033[91m[HIGH VALUE] {vehicle_info} - Rs {price:,}\033[0m")
        
    elif price < 1000000:
        alert = {
            "level": "LOW_PRICE",
            "message": f"Suspiciously Low Price: Rs {price:,}",
            "vehicle": vehicle_info
        }
        # Blue for Low Price
        print(f"\033[94m[LOW PRICE]  {vehicle_info} - Rs {price:,}\033[0m")

    else:
        # Green for Normal Price
        print(f"\033[92m[NORMAL]     {vehicle_info} - Rs {price:,}\033[0m")
        
    if alert:
        log_alert(alert)
