import sqlite3
import pandas as pd
import time
import os

# Connect to the SQLite database
DB_PATH = "car_stream.db"

def get_stats():
    """Fetch data from DB and calculate descriptive statistics"""
    try:
        if not os.path.exists(DB_PATH):
            print("Waiting for database creation...")
            return

        conn = sqlite3.connect(DB_PATH)
        query = "SELECT price, mileage, vehice_age as age FROM car_prices"
        df = pd.read_sql_query(query, conn)
        conn.close()

        if df.empty:
            print("No data available yet...")
            return

        pd.set_option('display.float_format', lambda x: '%.2f' % x)

        stats = df.describe()
        
        variance = df.var()
        skewness = df.skew()
        
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print("="*60)
        print("📊  REAL-TIME DESCRIPTIVE STATISTICS MONITOR")
        print("="*60)
        print(f"Total Records: {len(df)}")
        print(f"Last Updated:  {time.strftime('%H:%M:%S')}")
        print("-" * 60)
        
        print("\n--- PRICE STATISTICS (Rs) ---")
        print(stats['price'].to_string())
        print(f"variance    {variance['price']:.2f}")
        print(f"skewness    {skewness['price']:.2f}")

        print("\n--- MILEAGE STATISTICS (km) ---")
        print(stats['mileage'].to_string())
        
        print("\n--- VEHICLE AGE STATISTICS (years) ---")
        print(stats['age'].to_string())
        
    except Exception as e:
        print(f"Error calculating stats: {e}")

def main():
    print("Starting Statistics Consumer...")
    while True:
        get_stats()
        time.sleep(5)  # Update every 5 seconds

if __name__ == "__main__":
    main()
