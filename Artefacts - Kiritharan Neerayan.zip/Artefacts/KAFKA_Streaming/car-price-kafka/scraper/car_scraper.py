import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import logging

# Configure logging
logging.basicConfig(
    filename="pipeline.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class CarScraper: 
    BASE_URL = "https://ikman.lk"
    START_URL = "https://ikman.lk/en/ads/sri-lanka/cars"
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
        "Accept-Language": "en-US, en;q=0.5"
    }
    
    def __init__(self, num_pages=10, delay=1):

        self.num_pages = num_pages
        self.delay = delay
        self.links_list = []
        self.data = {
            "Brand": [],
            "Model": [],
            "Edition": [],
            "YOM": [],
            "Price": [],
            "Condition": [],
            "Transmission": [],
            "Body_Type": [],
            "Fuel_Type": [],
            "Engine_Capacity": [],
            "Mileage": []
        }
    
    def get_brand(self, soup):

        try:
            brand = soup.select_one("div.label--3oVZK:-soup-contains('Brand:') + div a span").text
        except AttributeError:
            brand = ""
        return brand
    
    def get_model(self, soup):

        try:
            model = soup.select_one("div.label--3oVZK:-soup-contains('Model:') + div a span").text
        except AttributeError:
            model = ""
        return model
    
    def get_edition(self, soup):

        try:
            edition = soup.select_one("div.label--3oVZK:-soup-contains('Trim / Edition:') + div").text
        except AttributeError:
            edition = ""
        return edition
    
    def get_yom(self, soup):

        try:
            yom = soup.select_one("div.label--3oVZK:-soup-contains('Year of Manufacture:') + div a span").text
        except AttributeError:
            yom = ""
        return yom
    
    def get_price(self, soup):

        try:
            price = soup.find("div", attrs={"class": 'amount--3NTpl'}).text
        except AttributeError:
            price = ""
        return price
    
    def get_condition(self, soup):

        try:
            condition = soup.select_one("div.label--3oVZK:-soup-contains('Condition:') + div a span").text
        except AttributeError:
            condition = ""
        return condition
    
    def get_transmission(self, soup):

        try:
            transmission = soup.select_one("div.label--3oVZK:-soup-contains('Transmission:') + div").text
        except AttributeError:
            transmission = ""
        return transmission
    
    def get_body_type(self, soup):

        try:
            body_type = soup.select_one("div.label--3oVZK:-soup-contains('Body type:') + div a span").text
        except AttributeError:
            body_type = ""
        return body_type
    
    def get_fuel_type(self, soup):

        try:
            fuel_type = soup.select_one("div.label--3oVZK:-soup-contains('Fuel type:') + div a span").text
        except AttributeError:
            fuel_type = ""
        return fuel_type
    
    def get_engine_capacity(self, soup):

        try:
            engine_capacity = soup.select_one("div.label--3oVZK:-soup-contains('Engine capacity:') + div").text
        except AttributeError:
            engine_capacity = ""
        return engine_capacity
    
    def get_mileage(self, soup):

        try:
            mileage = soup.select_one("div.label--3oVZK:-soup-contains('Mileage:') + div").text
        except AttributeError:
            mileage = ""
        return mileage
    
    def scrape_listing_links(self):

        logging.info(f"Starting to scrape {self.num_pages} pages")
        
        for page in range(1, self.num_pages + 1):
            try:
                print(f"Scraping page {page}")
                logging.info(f"Scraping page {page}")
                
                page_url = f"{self.START_URL}?page={page}"
                response = requests.get(page_url, headers=self.HEADERS, timeout=10)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, "html.parser")
                links = soup.find_all("a", class_="card-link--3ssYv gtm-ad-item")
                
                if not links:
                    logging.warning(f"No links found on page {page}")
                    break
                
                for link in links:
                    href = link.get("href")
                    if href:
                        self.links_list.append(self.BASE_URL + href)
                
                logging.info(f"Found {len(links)} listings on page {page}")
                time.sleep(self.delay)
                
            except requests.RequestException as e:
                logging.error(f"Error scraping page {page}: {e}")
                print(f"Error scraping page {page}: {e}")
        
        logging.info(f"Total links collected: {len(self.links_list)}")
        print(f"Total links collected: {len(self.links_list)}")
    
    def scrape_listing_details(self):

        logging.info(f"Starting to scrape details for {len(self.links_list)} listings")
        
        for idx, url in enumerate(self.links_list, 1):
            try:
                print(f"Scraping listing {idx}/{len(self.links_list)}")
                logging.info(f"Scraping listing {idx}: {url}")
                
                response = requests.get(url, headers=self.HEADERS, timeout=10)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, "html.parser")
                
                self.data["Brand"].append(self.get_brand(soup))
                self.data["Model"].append(self.get_model(soup))
                self.data["Edition"].append(self.get_edition(soup))
                self.data["YOM"].append(self.get_yom(soup))
                self.data["Price"].append(self.get_price(soup))
                self.data["Condition"].append(self.get_condition(soup))
                self.data["Transmission"].append(self.get_transmission(soup))
                self.data["Body_Type"].append(self.get_body_type(soup))
                self.data["Fuel_Type"].append(self.get_fuel_type(soup))
                self.data["Engine_Capacity"].append(self.get_engine_capacity(soup))
                self.data["Mileage"].append(self.get_mileage(soup))
                
                time.sleep(self.delay)
                
            except requests.RequestException as e:
                logging.error(f"Error scraping listing {url}: {e}")
                print(f"Error scraping listing {url}: {e}")
                # Append empty values to maintain data consistency
                for key in self.data.keys():
                    if len(self.data[key]) < idx:
                        self.data[key].append("")
        
        logging.info(f"Completed scraping {len(self.data['Brand'])} listings")
    
    def scrape(self):

        print("Starting web scraping...")
        logging.info("Starting web scraping process")
        
        # Step 1: Scrape listing links
        self.scrape_listing_links()
        
        if not self.links_list:
            logging.error("No listings found. Returning empty DataFrame.")
            print("No listings found.")
            return pd.DataFrame()
        
        # Step 2: Scrape details from each listing
        self.scrape_listing_details()
        
        # Step 3: Create DataFrame
        df = pd.DataFrame(self.data)
        
        logging.info(f"Scraping completed. Total records: {len(df)}")
        print(f"Scraping completed. Total records: {len(df)}")
        
        return df


def scrape_car_data(num_pages=5, delay=1):

    scraper = CarScraper(num_pages=num_pages, delay=delay)
    return scraper.scrape()


if __name__ == "__main__":
    # Test the scraper
    df = scrape_car_data(num_pages=2, delay=1)
    print("\nScraped Data Preview:")
    print(df.head())
    print(f"\nShape: {df.shape}")
    print(f"\nColumns: {df.columns.tolist()}")
