import json
import logging
import sys
import os
from kafka import KafkaConsumer, KafkaProducer

# Add parent directory to path to import transformer module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from transformer.data_transformer import DataTransformer

logging.basicConfig(
    filename="pipeline.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def main():
    print("\n" + "=" * 60)
    print("KAFKA STREAM PROCESSOR")
    print("Raw Data -> Data Transformer -> Cleaned Data")
    print("=" * 60)

    # Initialize Consumer
    try:
        consumer = KafkaConsumer(
            "car.raw.prices",
            bootstrap_servers="localhost:9092",
            auto_offset_reset="latest", # Start from new messages
            group_id="transformer-group",
            value_deserializer=lambda x: json.loads(x.decode("utf-8"))
        )
        print("✓ Connected to Kafka Consumer (car.raw.prices)")
    except Exception as e:
        print(f"✗ Failed to connect Consumer: {e}")
        sys.exit(1)

    # Initialize Producer
    try:
        producer = KafkaProducer(
            bootstrap_servers="localhost:9092",
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        print("✓ Connected to Kafka Producer (car.cleaned.prices)")
    except Exception as e:
        print(f"✗ Failed to connect Producer: {e}")
        sys.exit(1)

    # Initialize Transformer with empty DF (we use it for stateless methods + transform_record)
    transformer = DataTransformer(None)
    
    print("\nStream Processor Running...")
    print("Processing events...")

    processed_count = 0
    
    for msg in consumer:
        try:
            raw_event = msg.value
            
            # Transform
            cleaned_event = transformer.transform_record(raw_event)
            
            if cleaned_event:
                producer.send("car.cleaned.prices", value=cleaned_event)
                processed_count += 1
                
                # Feedback every 10 events or so
                if processed_count % 1 == 0:
                     print(f"Processed: {cleaned_event['brand']} {cleaned_event['model']} ({cleaned_event['year'] if 'year' in cleaned_event else cleaned_event.get('yom')})")
                
                logging.info(f"Processed event: {cleaned_event['vehicle_id']}")
            else:
                logging.warning(f"Invalid event skipped: {raw_event}")
                
        except Exception as e:
            logging.error(f"Error processing message: {e}")
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
