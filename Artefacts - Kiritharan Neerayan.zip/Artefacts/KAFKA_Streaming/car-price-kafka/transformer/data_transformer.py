

import pandas as pd
import numpy as np
import re
from datetime import datetime
import logging
import hashlib

logging.basicConfig(
    filename="pipeline.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


class DataTransformer:

    
    def __init__(self, df=None):

        self.df = df.copy() if df is not None else pd.DataFrame()
        self.current_year = datetime.now().year
    
    def clean_price(self, price_str):

        if pd.isna(price_str) or price_str == "":
            return 0
        
        try:
            # Remove currency symbols, commas, and spaces
            cleaned = re.sub(r'[Rs,\s]', '', str(price_str))
            return int(float(cleaned))
        except (ValueError, TypeError):
            logging.warning(f"Could not parse price: {price_str}")
            return 0
    
    def clean_engine_capacity(self, engine_str):

        if pd.isna(engine_str) or engine_str == "":
            return 0
        
        try:
            # Extract numbers and remove commas
            cleaned = re.sub(r'[,\s]', '', str(engine_str))
            # Extract just the number part
            match = re.search(r'\d+', cleaned)
            if match:
                return int(match.group())
            return 0
        except (ValueError, TypeError):
            logging.warning(f"Could not parse engine capacity: {engine_str}")
            return 0
    
    def clean_mileage(self, mileage_str):

        if pd.isna(mileage_str) or mileage_str == "":
            return 0
        
        try:
            # Remove commas, km, and spaces
            cleaned = re.sub(r'[,\skm]', '', str(mileage_str))
            return int(float(cleaned))
        except (ValueError, TypeError):
            logging.warning(f"Could not parse mileage: {mileage_str}")
            return 0
    
    def clean_yom(self, yom_str):

        if pd.isna(yom_str) or yom_str == "":
            return 0
        
        try:
            return int(yom_str)
        except (ValueError, TypeError):
            logging.warning(f"Could not parse YOM: {yom_str}")
            return 0
    
    def calculate_vehicle_age(self, yom):

        if yom == 0 or yom > self.current_year:
            return 0
        return self.current_year - yom
    
    def generate_vehicle_id(self, row):

        # Create a unique string from key attributes
        unique_str = f"{row['Brand']}_{row['Model']}_{row['YOM']}_{row['Price']}_{row['Mileage']}"
        # Generate hash
        hash_obj = hashlib.md5(unique_str.encode())
        return hash_obj.hexdigest()[:12]  # Use first 12 characters
    
    def transform(self):

        logging.info("Starting data transformation")
        
        # Clean and transform columns
        self.df['price'] = self.df['Price'].apply(self.clean_price)
        self.df['engine_cc'] = self.df['Engine_Capacity'].apply(self.clean_engine_capacity)
        self.df['mileage'] = self.df['Mileage'].apply(self.clean_mileage)
        self.df['yom'] = self.df['YOM'].apply(self.clean_yom)
        
        # Calculate vehicle age
        self.df['vehice_age'] = self.df['yom'].apply(self.calculate_vehicle_age)
        
        # Rename and select columns
        self.df['brand'] = self.df['Brand'].str.strip()
        self.df['model'] = self.df['Model'].str.strip()
        
        # Add current date
        self.df['date'] = datetime.now().strftime('%Y-%m-%d')
        
        # Generate vehicle IDs
        self.df['vehicle_id'] = self.df.apply(self.generate_vehicle_id, axis=1)
        
        # Select final columns matching Kafka schema
        final_df = self.df[[
            'vehicle_id',
            'brand',
            'model',
            'yom',
            'vehice_age',
            'engine_cc',
            'mileage',
            'price',
            'date'
        ]].copy()
        
        # Remove rows with invalid data (e.g., price = 0, yom = 0)
        initial_count = len(final_df)
        final_df = final_df[
            (final_df['price'] > 0) & 
            (final_df['yom'] > 0) &
            (final_df['brand'] != '') &
            (final_df['model'] != '')
        ]
        
        removed_count = initial_count - len(final_df)
        if removed_count > 0:
            logging.info(f"Removed {removed_count} invalid records")
            print(f"Removed {removed_count} invalid records")
        
        logging.info(f"Transformation completed. Valid records: {len(final_df)}")
        print(f"Transformation completed. Valid records: {len(final_df)}")
        
        return final_df

    def transform_record(self, record):

        try:
            # Clean fields
            # Handle potential different key casing or missing keys
            price_val = record.get('Price', record.get('price', '0'))
            engine_val = record.get('Engine_Capacity', record.get('engine_capacity', '0 cc'))
            mileage_val = record.get('Mileage', record.get('mileage', '0 km'))
            yom_val = record.get('YOM', record.get('yom', '0'))
            
            clean_price = self.clean_price(price_val)
            clean_engine = self.clean_engine_capacity(engine_val)
            clean_mileage = self.clean_mileage(mileage_val)
            clean_yom = self.clean_yom(yom_val)
            
            # Validation
            if clean_price <= 0 or clean_yom <= 0:
                return None
            
            vehicle_age = self.calculate_vehicle_age(clean_yom)
            
            brand = str(record.get('Brand', record.get('brand', ''))).strip()
            model = str(record.get('Model', record.get('model', ''))).strip()
            
            if not brand or not model:
                return None
            
            # Generate ID
            # Reconstruct the row-like object for generate_vehicle_id
            # But generate_vehicle_id expects a row with specific keys. 
            # Let's just reimplement ID generation here for simplicity and safety
            unique_str = f"{brand}_{model}_{clean_yom}_{record.get('Price', '')}_{record.get('Mileage', '')}"
            hash_obj = hashlib.md5(unique_str.encode())
            vehicle_id = hash_obj.hexdigest()[:12]
            
            transformed = {
                'vehicle_id': vehicle_id,
                'brand': brand,
                'model': model,
                'yom': clean_yom,
                'vehice_age': vehicle_age,
                'engine_cc': clean_engine,
                'mileage': clean_mileage,
                'price': clean_price,
                'date': datetime.now().strftime('%Y-%m-%d')
            }
            
            return transformed
            
        except Exception as e:
            logging.error(f"Error converting record: {e}")
            return None

def transform_scraped_data(df):

    transformer = DataTransformer(df)
    return transformer.transform()


if __name__ == "__main__":
    # Test the transformer with sample data
    sample_data = {
        'Brand': ['Toyota', 'Honda', 'Nissan'],
        'Model': ['Aqua', 'Fit', 'March'],
        'Edition': ['G', 'Hybrid', 'X'],
        'YOM': ['2018', '2019', '2017'],
        'Price': ['Rs 5,500,000', 'Rs 4,800,000', 'Rs 3,200,000'],
        'Condition': ['Used', 'Used', 'Used'],
        'Transmission': ['Automatic', 'Automatic', 'Automatic'],
        'Body_Type': ['Hatchback', 'Hatchback', 'Hatchback'],
        'Fuel_Type': ['Petrol', 'Petrol', 'Petrol'],
        'Engine_Capacity': ['1,500 cc', '1,300 cc', '1,200 cc'],
        'Mileage': ['50,000 km', '35,000 km', '75,000 km']
    }
    
    df = pd.DataFrame(sample_data)
    print("Original Data:")
    print(df)
    
    transformed_df = transform_scraped_data(df)
    print("\nTransformed Data:")
    print(transformed_df)
    print(f"\nData types:\n{transformed_df.dtypes}")
