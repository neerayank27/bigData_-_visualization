import Header from '../components/layout/Header';
import TimeSeriesScatter from '../components/charts/TimeSeriesScatter';

export default function TimeSeriesPage() {
  return (
    <div className="space-y-6">
      <Header 
        title="Time Series Analysis" 
        subtitle="Track average price trends over time"
      />
      
      <div className="glass rounded-xl p-6">
        <TimeSeriesScatter height={550} />
      </div>
    </div>
  );
}
