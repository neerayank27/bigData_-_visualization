import Header from '../components/layout/Header';
import ScatterPlot from '../components/charts/ScatterPlot';

export default function ScatterPage() {
  return (
    <div className="space-y-6">
      <Header 
        title="Scatter Plot Analysis" 
        subtitle="Explore relationships between numeric variables"
      />
      
      <div className="glass rounded-xl p-6">
        <ScatterPlot height={550} />
      </div>
    </div>
  );
}
