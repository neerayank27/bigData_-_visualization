import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useData } from '../context/DataContext';
import PieChart from '../components/charts/PieChart';
import BarChart from '../components/charts/BarChart';
import Header from '../components/layout/Header';
import { PieChart as PieIcon, BarChart as BarIcon, Filter } from 'lucide-react';

export default function CategoricalPage() {
  const { types, updateFilter, filters, clearFilters, sheets, activeSheet, switchSheet } = useData();
  const [pieVariable, setPieVariable] = useState('');
  const [barVariable, setBarVariable] = useState('');

  // efficient default selection
  useEffect(() => {
    if (types.categorical && types.categorical.length > 0) {
      if (!pieVariable) setPieVariable(types.categorical[0]);
      if (!barVariable) setBarVariable(types.categorical[1] || types.categorical[0]);
    }
  }, [types, pieVariable, barVariable]);

  if (!types.categorical || types.categorical.length === 0) {
     return <div className="p-10 text-center text-slate-500">No categorical data found in dataset.</div>;
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <Header 
          title="Categorical Analysis" 
          subtitle="Deep dive into categorical data distributions"
        />
        <div className="flex items-center gap-3">
             {sheets && Object.keys(sheets).length > 1 && (
                 <select 
                   value={activeSheet || ''}
                   onChange={(e) => switchSheet(e.target.value)}
                   className="bg-white border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 py-2 outline-none shadow-sm"
                 >
                   {Object.keys(sheets).map(s => <option key={s} value={s}>{s}</option>)}
                 </select>
             )}
             {(Object.keys(filters).length > 0) && (
                 <button 
                   onClick={clearFilters}
                   className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm font-medium"
                 >
                   <Filter size={16} />
                   Clear Filters
                 </button>
             )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart Section */}
        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm min-h-[450px]"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <PieIcon className="text-blue-500" size={20}/>
               Composition Analysis
             </h3>
             <select
               value={pieVariable}
               onChange={(e) => setPieVariable(e.target.value)}
               className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 outline-none"
             >
               {types.categorical.map(c => <option key={c} value={c}>{c}</option>)}
             </select>
          </div>
          <div className="h-[350px]">
            {pieVariable && (
                <PieChart 
                    categoryField={pieVariable} 
                    height={350} 
                    onSliceClick={(val) => updateFilter(pieVariable, val)}
                />
            )}
          </div>
          <p className="text-xs text-center text-slate-400 mt-4">Click slices to filter dashboard</p>
        </motion.div>

        {/* Bar Chart Section */}
        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm min-h-[450px]"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <BarIcon className="text-emerald-500" size={20}/>
               Frequency Distribution
             </h3>
             <select
               value={barVariable}
               onChange={(e) => setBarVariable(e.target.value)}
               className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block p-2 outline-none"
             >
               {types.categorical.map(c => <option key={c} value={c}>{c}</option>)}
             </select>
          </div>
          <div className="h-[350px]">
             {barVariable && (
                <BarChart 
                    categoryField={barVariable} 
                    height={350}
                    maxBars={12}
                    onBarClick={(val) => updateFilter(barVariable, val)}
                />
             )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
