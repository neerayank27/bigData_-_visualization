import Header from '../components/layout/Header';
import Histogram from '../components/charts/Histogram';

export default function HistogramPage() {
  return (
    <div className="space-y-6">
      <Header 
        title="Distribution Analysis" 
        subtitle="Explore frequency distributions of numeric variables"
      />
      
      <div className="glass rounded-xl p-6">
        <Histogram height={500} />
      </div>
    </div>
  );
}
