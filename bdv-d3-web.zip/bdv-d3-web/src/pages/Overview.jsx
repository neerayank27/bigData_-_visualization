import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useData } from '../context/DataContext';
import KPICard from '../components/ui/KPICard';
import PieChart from '../components/charts/PieChart';
import BarChart from '../components/charts/BarChart';
import Header from '../components/layout/Header';
import { TrendingUp, Car, Tag, Activity, Calendar, FilterX } from 'lucide-react';
import { formatCurrency } from '../utils/d3Helpers';

export default function Overview() {
  const { filteredData, metadata, types, loading, updateFilter, clearFilters, filters } = useData();

  const brandsByYOM = useMemo(() => {
     if (!filteredData) return [];
     const groups = {};
     filteredData.forEach(d => {
       const yom = d.YOM;
       if (!yom) return;
       if (!groups[yom]) groups[yom] = new Set();
       groups[yom].add(d.Brand);
     });
     
     return Object.entries(groups)
       .map(([year, brands]) => ({
         category: year,
         count: brands.size // Number of unique brands
       }))
       .sort((a,b) => parseInt(a.category) - parseInt(b.category));
  }, [filteredData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen text-slate-400">Loading...</div>
    );
  }

  const currentCount = filteredData.length;
  const avgPrice = currentCount ? filteredData.reduce((acc, d) => acc + (d.Price || 0), 0) / currentCount : 0;
  const avgAge = currentCount ? filteredData.reduce((acc, d) => acc + (d.Vehicle_Age || 0), 0) / currentCount : 0;
  const uniqueBrands = new Set(filteredData.map(d => d.Brand)).size;
  const uniqueModels = new Set(filteredData.map(d => d.Model)).size;

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <Header 
          title="Dashboard Overview" 
          subtitle="Interactive vehicle price analytics"
        />
        {(Object.keys(filters).length > 0) && (
          <button 
            onClick={clearFilters}
            className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm font-medium"
          >
            <FilterX size={16} />
            Clear Filters
          </button>
        )}
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Avg. Price"
          value={formatCurrency(avgPrice)}
          subtitle={`${currentCount.toLocaleString()} vehicles`}
          icon={TrendingUp}
          gradient="from-blue-500 to-blue-600"
        />
        <KPICard
          title="Avg. Vehicle Age"
          value={`${avgAge.toFixed(1)} Years`}
          subtitle="Model Year Analysis"
          icon={Car}
          gradient="from-slate-500 to-slate-600"
        />
        <KPICard
          title="No of Brands"
          value={uniqueBrands}
          subtitle="Active Manufacturers"
          icon={Tag}
          gradient="from-indigo-500 to-indigo-600"
        />
        <KPICard
          title="No of Models"
          value={uniqueModels.toLocaleString()}
          subtitle="Vehicle Models"
          icon={Activity}
          gradient="from-emerald-500 to-emerald-600"
        />
      </div>

      {/* Row 1: Brands vs YOM & Weekly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
             <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <Calendar className="text-primary-500" size={20}/>
               Brands per Year (YOM)
             </h3>
          </div>
          <BarChart 
            data={brandsByYOM} 
            categoryField="category" 
            valueField={null} // Use default 'count' which we populated
            height={350}
            onBarClick={(year) => updateFilter('YOM', parseInt(year))}
          />
        </motion.div>

        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.1}}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <TrendingUp className="text-primary-500" size={20}/>
               Market Share by Brand
             </h3>
          </div>
          <PieChart 
            categoryField="Brand"
            height={350}
            onSliceClick={(brand) => updateFilter('Brand', brand)}
          />
          <p className="text-xs text-center text-slate-400 mt-2">Click slice to filter by Brand</p>
        </motion.div>
      </div>

      {/* Row 2: Top Brands & Models (Interactive) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.2}}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm"
        >
          <h3 className="text-lg font-bold text-slate-800 mb-4">Top Brands by Volume</h3>
          <BarChart 
            data={filteredData}
            categoryField="Brand" 
            height={350} 
            maxBars={10}
            onBarClick={(brand) => updateFilter('Brand', brand)}
          />
        </motion.div>

        <motion.div
           initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.3}}
           className="glass rounded-xl p-6 bg-white border border-slate-100 shadow-sm"
        >
          <h3 className="text-lg font-bold text-slate-800 mb-4">Top Models by Volume</h3>
          <BarChart 
             data={filteredData}
             categoryField="Model" 
             height={350} 
             maxBars={10} 
             onBarClick={(model) => updateFilter('Model', model)}
          />
        </motion.div>
      </div>
    </div>
  );
}
