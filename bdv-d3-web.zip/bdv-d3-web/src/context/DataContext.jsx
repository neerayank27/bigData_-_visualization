import { createContext, useContext, useState, useEffect } from 'react';
import { loadDataFile, detectVariableTypes, cleanData } from '../utils/dataLoader';
import { generateMetadata } from '../utils/dataAnalyzer';

const DataContext = createContext();

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within DataProvider');
  }
  return context;
}

export function DataProvider({ children }) {
  const [rawData, setRawData] = useState([]);
  const [sheets, setSheets] = useState({});
  const [activeSheet, setActiveSheet] = useState(null);
  const [data, setData] = useState([]);
  const [types, setTypes] = useState({ numeric: [], categorical: [], date: [] });
  const [metadata, setMetadata] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        
        const loaded = await loadDataFile('/car_price_cleaned_visualization.xlsx'); // Load the Excel file
        setRawData(loaded);
        
        // Handle multiple sheets
        if (loaded.sheets) {
            setSheets(loaded.sheets);
            const sheetNames = Object.keys(loaded.sheets);
            setActiveSheet(sheetNames[0]);
        }
        
        const detectedTypes = detectVariableTypes(loaded); // Detect variable types
        setTypes(detectedTypes);
        
        const cleaned = cleanData(loaded, detectedTypes); // Clean data
        setData(cleaned);
        
        const meta = generateMetadata(cleaned, detectedTypes); // Generate metadata
        setMetadata(meta);
        
        setLoading(false);
      } catch (err) {
        console.error('Error loading data:', err);
        setError(err.message);
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const [filters, setFilters] = useState({});
  const [filteredData, setFilteredData] = useState([]);

  // ... (loadData logic remains)

  // Apply filters whenever filters or data change
  useEffect(() => {
    if (Object.keys(filters).length === 0) {
      setFilteredData(data);
      return;
    }

    const filtered = data.filter(row => {
      return Object.entries(filters).every(([key, value]) => {
        if (value === null || value === undefined) return true;
        return row[key] === value;
      });
    });
    setFilteredData(filtered);
  }, [data, filters]);

  const updateFilter = (key, value) => {
    setFilters(prev => {
      // Toggle filter: if same value, remove it
      if (prev[key] === value) {
        const { [key]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [key]: value };
    });
  };

  const clearFilters = () => setFilters({});

  const value = {
    rawData,
    data, // All data
    filteredData, // Filtered subset
    sheets, // All sheets
    activeSheet,
    switchSheet: (sheetName) => {
        if (sheets[sheetName]) {
            setLoading(true);
            setActiveSheet(sheetName);
            const newData = cleanData(sheets[sheetName], detectVariableTypes(sheets[sheetName]));
            setTypes(detectVariableTypes(sheets[sheetName])); // Update types for new data
            setData(newData);
            setMetadata(generateMetadata(newData, detectVariableTypes(sheets[sheetName])));
            setFilters({}); // Clear filters when switching dataset
            setLoading(false);
        }
    },
    filters,
    updateFilter,
    clearFilters,
    types,
    metadata,
    loading,
    error
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
}
