import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { DataProvider } from './context/DataContext';
import Sidebar from './components/layout/Sidebar';
import Overview from './pages/Overview';
import HistogramPage from './pages/HistogramPage';
import ScatterPage from './pages/ScatterPage';
import TimeSeriesPage from './pages/TimeSeriesPage';
import CategoricalPage from './pages/CategoricalPage';

function App() {
  return (
    <DataProvider>
      <Router>
        <div className="flex min-h-screen bg-dark-bg">
          <Sidebar />
          
          <main className="flex-1 ml-64 p-8">
            <div className="max-w-7xl mx-auto">
              <AnimatePresence mode="wait">
                <Routes>
                  <Route path="/" element={<Overview />} />
                  <Route path="/histogram" element={<HistogramPage />} />
                  <Route path="/scatter" element={<ScatterPage />} />
                  <Route path="/timeseries" element={<TimeSeriesPage />} />
                  <Route path="/categorical" element={<CategoricalPage />} />
                </Routes>
              </AnimatePresence>
            </div>
          </main>
        </div>
      </Router>
    </DataProvider>
  );
}

export default App;
