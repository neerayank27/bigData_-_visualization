import * as XLSX from 'xlsx';

/**
 * Load and parse Excel/CSV/JSON data file
 * @param {string} filePath - Path to the data file
 * @returns {Promise<Array>} Parsed data array
 */
export async function loadDataFile(filePath) {
  try {
    const response = await fetch(filePath);
    const arrayBuffer = await response.arrayBuffer();
    
    // Parse Excel file
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    
    // Parse ALL sheets
    const sheets = {};
    workbook.SheetNames.forEach(sheetName => {
        const worksheet = workbook.Sheets[sheetName];
        const sheetData = XLSX.utils.sheet_to_json(worksheet, { 
            raw: false,
            dateNF: 'yyyy-mm-dd'
        });
        if (sheetData.length > 0) {
            sheets[sheetName] = sheetData;
        }
    });

    const sheetNames = Object.keys(sheets);
    if (sheetNames.length === 0) return [];

    // Default data is the first sheet (backward compatibility)
    const defaultData = sheets[sheetNames[0]];
    
    // Attach sheets object to the array (hacky but preserves API)
    defaultData.sheets = sheets;
    
    console.log(`✅ Loaded ${Object.keys(sheets).length} sheets`);
    return defaultData;
  } catch (error) {
    console.error('Error loading data file:', error);
    throw new Error(`Failed to load data: ${error.message}`);
  }
}

/**
 * Detect variable types in dataset
 * @param {Array} data - Dataset array
 * @returns {Object} Variable types categorized
 */
export function detectVariableTypes(data) {
  if (!data || data.length === 0) return { numeric: [], categorical: [], date: [] };
  
  const sample = data[0];
  const keys = Object.keys(sample);
  
  const numeric = [];
  const categorical = [];
  const dateFields = [];
  
  keys.forEach(key => {
    const values = data.slice(0, 100).map(row => row[key]).filter(v => v != null);
    
    if (values.length === 0) return;
    
    // Check if date
    const isDate = values.every(v => {
      const parsed = new Date(v);
      return !isNaN(parsed.getTime()) && (
        typeof v === 'string' && (
          v.includes('-') || v.includes('/') || v.match(/\d{4}/)
        )
      );
    });
    
    if (isDate) {
      dateFields.push(key);
      return;
    }
    
    // Check if numeric
    // Use a loose check that handles commas in strings
    const numericValues = values.filter(v => {
        if (typeof v === 'number') return true;
        if (typeof v === 'string') {
            const clean = v.replace(/[,$\s]/g, ''); // Remove format chars
            return !isNaN(parseFloat(clean)) && clean.length > 0;
        }
        return false;
    });
    
    const isNumeric = numericValues.length / values.length > 0.8;
    
    if (isNumeric) {
      numeric.push(key);
    } else {
      categorical.push(key);
    }
  });

  // Always treat likely derived fields as numeric if not already
  ['Vehicle_Age', 'YOM', 'Year', 'Price'].forEach(f => {
      // Find matching key (case insensitive)
      const matchingKey = keys.find(k => k.toLowerCase() === f.toLowerCase());
      if (matchingKey && !numeric.includes(matchingKey) && !dateFields.includes(matchingKey)) {
          numeric.push(matchingKey);
      }
  });
  
  // Clean duplicates
  return { numeric: [...new Set(numeric)], categorical, date: dateFields };
}

/**
 * Parse numeric value safely
 * @param {any} value - Value to parse
 * @returns {number|null} Parsed number or null
 */
export function parseNumeric(value) {
  if (value == null || value === '') return null;
    if (typeof value === 'number') return value;
    // Remove commas, currency symbols, and spaces
    const cleanStr = String(value).replace(/[,$\sLKR]/g, '');
    const num = parseFloat(cleanStr);
    return isNaN(num) ? null : num;
}

/**
 * Parse date value safely
 * @param {any} value - Value to parse
 * @returns {Date|null} Parsed date or null
 */
export function parseDate(value) {
  if (!value) return null;
  const date = new Date(value);
  return isNaN(date.getTime()) ? null : date;
}

/**
 * Clean and prepare dataset
 * @param {Array} data - Raw dataset
 * @param {Object} types - Variable types
 * @returns {Array} Cleaned dataset
 */
export function cleanData(data, types) {
  const currentYear = new Date().getFullYear();

  return data.map(row => {
    // Clone
    const cleaned = { ...row };
    
    // Parse numeric fields with extra care
    types.numeric.forEach(field => {
       cleaned[field] = parseNumeric(row[field]);
    });
    
    // Parse date fields
    types.date.forEach(field => {
      cleaned[field] = parseDate(row[field]);
    });

    // --- DERIVED FIELDS LOGIC ---

    // Find YOM/Year field (Case insensitive search)
    const yearKey = Object.keys(row).find(k => /^(yom|year|model\s*year|manufacture\s*year)$/i.test(k));
    let yom = yearKey ? parseNumeric(row[yearKey]) : null;

    if (yom) {
      cleaned['YOM'] = yom;
      // Also ensure standard 'YOM' key exists if it was named something else
      if (yearKey !== 'YOM') cleaned['YOM'] = yom;
    }

    // Find Price field
    const priceKey = Object.keys(row).find(k => /^(price|amount|value|selling\s*price)$/i.test(k));
    if (priceKey) {
        const val = parseNumeric(row[priceKey]);
        if (val !== null) cleaned['Price'] = val;
    }

    // Calculate/Fix Vehicle Age
    let age = null;
    const ageKey = Object.keys(row).find(k => /^(vehicle\s*age|age)$/i.test(k));
    if (ageKey) {
        age = parseNumeric(row[ageKey]);
    }

    // Calculate Age from YOM if missing or invalid
    if (yom && (age === null || age < 0 || age > 100)) { 
       age = currentYear - yom;
    }

    // Calculate YOM from Age if missing or invalid
    if (age !== null && (!yom || yom < 1900)) { 
       yom = currentYear - Math.floor(age);
       cleaned['YOM'] = yom;
    }

    cleaned['Vehicle_Age'] = age !== null && age >= 0 ? age : null;
    
    // Ensure Week calculation can happen in analyzer by ensuring Date exists
    // If Date field is missing, maybe we can't do much. 

    return cleaned;
  }).filter(row => {
    // Basic validity check
    // We want at least some useful data, but don't filter too strictly to avoid empty dashboard
    return true; 
  });
}
