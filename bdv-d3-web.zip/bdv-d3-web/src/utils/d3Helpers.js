import * as d3 from 'd3';

/**
 * D3 helper utilities for reusable chart components
 */

/**
 * Create responsive SVG with margins
 * @param {HTMLElement} container - Container element
 * @param {Object} margin - Margin object {top, right, bottom, left}
 * @returns {Object} SVG dimensions and selection
 */
export function createResponsiveSVG(container, margin = { top: 20, right: 20, bottom: 40, left: 60 }) {
  const containerRect = container.getBoundingClientRect();
  const width = containerRect.width;
  const height = containerRect.height || 400;
  
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;
  
  return {
    width,
    height,
    innerWidth,
    innerHeight,
    margin
  };
}

/**
 * Format number with appropriate suffix (K, M, B)
 * @param {number} num - Number to format
 * @returns {string} Formatted string
 */
export function formatNumber(num) {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
  return num.toFixed(0);
}

/**
 * Format currency
 * @param {number} value - Value to format
 * @returns {string} Formatted currency
 */
export function formatCurrency(value) {
  return new Intl.NumberFormat('en-LK', {
    style: 'currency',
    currency: 'LKR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value);
}

/**
 * Format date
 * @param {Date} date - Date to format
 * @param {string} format - Format type ('short', 'medium', 'long')
 * @returns {string} Formatted date
 */
export function formatDate(date, format = 'short') {
  if (!date) return '';
  if (!(date instanceof Date)) date = new Date(date);
  if (isNaN(date.getTime())) return '';
  
  const formats = {
    short: d3.timeFormat('%d/%m/%Y'),
    medium: d3.timeFormat('%b %d, %Y'),
    long: d3.timeFormat('%B %d, %Y'),
    yearMonth: d3.timeFormat('%b %Y'),
    year: d3.timeFormat('%Y'),
    week: d3.timeFormat('W%V %Y') // Week number
  };
  
  return formats[format] ? formats[format](date) : formats.short(date);
}

/**
 * Create color scale
 * @param {Array} domain - Domain values
 * @param {Array} colors - Color array (optional)
 * @returns {Function} D3 color scale
 */
export function createColorScale(domain, colors = null) {
  if (colors) {
    return d3.scaleOrdinal()
      .domain(domain)
      .range(colors);
  }
  
  // Default gradient colors
  const defaultColors = [
    '#0ea5e9', '#38bdf8', '#7dd3fc',
    '#d946ef', '#e879f9', '#f0abfc',
    '#f59e0b', '#fbbf24', '#fcd34d'
  ];
  
  return d3.scaleOrdinal()
    .domain(domain)
    .range(defaultColors);
}

/**
 * Create gradient definition
 * @param {d3.Selection} svg - SVG selection
 * @param {string} id - Gradient ID
 * @param {Array} colors - Color stops [{offset, color}]
 * @returns {string} Gradient ID
 */
export function createGradient(svg, id, colors) {
  const defs = svg.select('defs').empty() 
    ? svg.append('defs') 
    : svg.select('defs');
  
  const gradient = defs.append('linearGradient')
    .attr('id', id)
    .attr('x1', '0%')
    .attr('y1', '0%')
    .attr('x2', '100%')
    .attr('y2', '0%');
  
  colors.forEach(({ offset, color }) => {
    gradient.append('stop')
      .attr('offset', offset)
      .attr('stop-color', color);
  });
  
  return `url(#${id})`;
}

/**
 * Create tooltip
 * @param {HTMLElement} container - Container element
 * @returns {d3.Selection} Tooltip selection
 */
export function createTooltip(container) {
  return d3.select(container)
    .append('div')
    .attr('class', 'd3-tooltip')
    .style('position', 'absolute')
    .style('pointer-events', 'none')
    .style('opacity', 0);
}

/**
 * Show tooltip
 * @param {d3.Selection} tooltip - Tooltip selection
 * @param {string} content - HTML content
 * @param {MouseEvent} event - Mouse event
 */
export function showTooltip(tooltip, content, event) {
  tooltip
    .html(content)
    .classed('visible', true)
    .style('opacity', 1)
    .style('left', (event.pageX + 10) + 'px')
    .style('top', (event.pageY - 10) + 'px');
}

/**
 * Hide tooltip
 * @param {d3.Selection} tooltip - Tooltip selection
 */
export function hideTooltip(tooltip) {
  tooltip
    .classed('visible', false)
    .style('opacity', 0);
}

/**
 * Add grid lines to chart
 * @param {d3.Selection} g - Group selection
 * @param {Function} xScale - X scale
 * @param {Function} yScale - Y scale
 * @param {number} width - Chart width
 * @param {number} height - Chart height
 */
export function addGridLines(g, xScale, yScale, width, height) {
  // X grid lines
  g.append('g')
    .attr('class', 'grid grid-x')
    .attr('transform', `translate(0,${height})`)
    .call(
      d3.axisBottom(xScale)
        .tickSize(-height)
        .tickFormat('')
    )
    .style('stroke', 'rgba(255, 255, 255, 0.05)')
    .style('stroke-dasharray', '2,2');
  
  // Y grid lines
  g.append('g')
    .attr('class', 'grid grid-y')
    .call(
      d3.axisLeft(yScale)
        .tickSize(-width)
        .tickFormat('')
    )
    .style('stroke', 'rgba(255, 255, 255, 0.05)')
    .style('stroke-dasharray', '2,2');
}

/**
 * Wrap text for axis labels
 * @param {d3.Selection} text - Text selection
 * @param {number} width - Max width
 */
export function wrapText(text, width) {
  text.each(function() {
    const text = d3.select(this);
    const words = text.text().split(/\s+/).reverse();
    let word;
    let line = [];
    let lineNumber = 0;
    const lineHeight = 1.1;
    const y = text.attr('y');
    const dy = parseFloat(text.attr('dy') || 0);
    let tspan = text.text(null).append('tspan').attr('x', 0).attr('y', y).attr('dy', dy + 'em');
    
    while (word = words.pop()) {
      line.push(word);
      tspan.text(line.join(' '));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(' '));
        line = [word];
        tspan = text.append('tspan').attr('x', 0).attr('y', y).attr('dy', ++lineNumber * lineHeight + dy + 'em').text(word);
      }
    }
  });
}

/**
 * Transition helper
 * @param {number} duration - Duration in ms
 * @returns {d3.Transition} D3 transition
 */
export function createTransition(duration = 750) {
  return d3.transition()
    .duration(duration)
    .ease(d3.easeCubicInOut);
}
