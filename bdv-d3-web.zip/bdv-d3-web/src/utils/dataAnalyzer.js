/**
 * Data analysis utilities for generating insights and metadata
 */

/**
 * Calculate summary statistics for a numeric variable
 * @param {Array} data - Dataset
 * @param {string} field - Field name
 * @returns {Object} Statistics object
 */
export function calculateStats(data, field) {
  const values = data
    .map(row => parseFloat(row[field]))
    .filter(v => !isNaN(v) && v != null);
  
  if (values.length === 0) {
    return { count: 0, mean: 0, median: 0, min: 0, max: 0, std: 0 };
  }
  
  const sorted = [...values].sort((a, b) => a - b);
  const count = values.length;
  const sum = values.reduce((acc, v) => acc + v, 0);
  const mean = sum / count;
  
  const median = count % 2 === 0
    ? (sorted[count / 2 - 1] + sorted[count / 2]) / 2
    : sorted[Math.floor(count / 2)];
  
  if (values.length < 2) return { count: values.length, mean: values[0] || 0, median: values[0] || 0, min: values[0] || 0, max: values[0] || 0, std: 0, sum: values[0] || 0 };

  const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (count - 1);
  const std = Math.sqrt(variance);
  
  return {
    count,
    mean,
    median,
    min: sorted[0],
    max: sorted[count - 1],
    std,
    sum
  };
}

/**
 * Generate metadata for the entire dataset
 * @param {Array} data - Dataset
 * @param {Object} types - Variable types
 * @returns {Object} Metadata object
 */
export function generateMetadata(data, types) {
  const metadata = {
    totalRows: data.length,
    fields: {},
    summary: {}
  };
  
  // Analyze numeric fields
  types.numeric.forEach(field => {
    const stats = calculateStats(data, field);
    metadata.fields[field] = {
      type: 'numeric',
      ...stats
    };
  });
  
  // Analyze categorical fields
  types.categorical.forEach(field => {
    const values = data.map(row => row[field]).filter(v => v != null);
    const unique = [...new Set(values)];
    const distribution = {};
    
    values.forEach(v => {
      distribution[v] = (distribution[v] || 0) + 1;
    });
    
    metadata.fields[field] = {
      type: 'categorical',
      uniqueCount: unique.length,
      distribution,
      topValues: Object.entries(distribution)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([value, count]) => ({ value, count }))
    };
  });
  
  // Analyze date fields
  types.date.forEach(field => {
    const dates = data
      .map(row => new Date(row[field]))
      .filter(d => !isNaN(d.getTime()));
    
    if (dates.length > 0) {
      const sorted = dates.sort((a, b) => a - b);
      metadata.fields[field] = {
        type: 'date',
        count: dates.length,
        min: sorted[0],
        max: sorted[dates.length - 1]
      };
    }
  });
  
  return metadata;
}

/**
 * Aggregate data by date and calculate average
 * @param {Array} data - Dataset
 * @param {string} dateField - Date field name
 * @param {string} valueField - Value field name
 * @returns {Array} Aggregated data
 */
export function aggregateByDate(data, dateField, valueField) {
  const grouped = {};
  
  data.forEach(row => {
    const date = row[dateField];
    const value = parseFloat(row[valueField]);
    
    if (!date || isNaN(value)) return;
    
    const dateKey = date instanceof Date 
      ? date.toISOString().split('T')[0]
      : new Date(date).toISOString().split('T')[0];
    
    if (!grouped[dateKey]) {
      grouped[dateKey] = { values: [], date: new Date(dateKey) };
    }
    
    grouped[dateKey].values.push(value);
  });
  
  return Object.values(grouped)
    .map(({ date, values }) => ({
      date,
      average: values.reduce((a, b) => a + b, 0) / values.length,
      count: values.length,
      min: Math.min(...values),
      max: Math.max(...values)
    }))
    .sort((a, b) => a.date - b.date);
}

/**
 * Aggregate data by week
 */
export function aggregateByWeek(data, dateField, valueField) {
   const grouped = {};
   const getWeek = (d) => {
      const date = new Date(d);
      date.setHours(0, 0, 0, 0);
      date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
      const week1 = new Date(date.getFullYear(), 0, 4);
      return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
   };

   data.forEach(row => {
    const dateVal = row[dateField];
    const value = parseFloat(row[valueField]);
    
    if (!dateVal || isNaN(value)) return;
    const d = new Date(dateVal);
    if(isNaN(d.getTime())) return;

    const year = d.getFullYear();
    const week = getWeek(d);
    const key = `${year}-W${week}`; // e.g., 2024-W01

    if (!grouped[key]) {
      grouped[key] = { values: [], label: key, year, week, firstDate: d };
    }
    // Update first date if this row is earlier
    if (d < grouped[key].firstDate) grouped[key].firstDate = d;

    grouped[key].values.push(value);
   });

   return Object.values(grouped).map(item => ({
     label: item.label,
     date: item.firstDate, // Use first date of week for plotting
     average: item.values.reduce((a,b)=>a+b,0)/item.values.length,
     count: item.values.length
   })).sort((a,b) => a.date - b.date);
}

/**
 * Aggregate data by category
 * @param {Array} data - Dataset
 * @param {string} categoryField - Category field name
 * @param {string} valueField - Value field name (optional)
 * @returns {Array} Aggregated data
 */
export function aggregateByCategory(data, categoryField, valueField = null) {
  const grouped = {};
  
  data.forEach(row => {
    const category = row[categoryField];
    if (!category) return;
    
    if (!grouped[category]) {
      grouped[category] = { category, count: 0, values: [] };
    }
    
    grouped[category].count++;
    
    if (valueField) {
      const value = parseFloat(row[valueField]);
      if (!isNaN(value)) {
        grouped[category].values.push(value);
      }
    }
  });
  
  return Object.values(grouped)
    .map(item => {
      if (item.values.length > 0) {
        return {
          category: item.category,
          count: item.count,
          average: item.values.reduce((a, b) => a + b, 0) / item.values.length,
          total: item.values.reduce((a, b) => a + b, 0)
        };
      }
      return {
        category: item.category,
        count: item.count
      };
    })
    .sort((a, b) => b.count - a.count);
}

/**
 * Calculate histogram bins
 * @param {Array} data - Dataset
 * @param {string} field - Field name
 * @param {number} numBins - Number of bins (default: 20)
 * @returns {Array} Histogram bins
 */
export function calculateHistogramBins(data, field, numBins = 20) {
  const values = data
    .map(row => parseFloat(row[field]))
    .filter(v => !isNaN(v) && v != null);
  
  if (values.length === 0) return [];
  
  const min = Math.min(...values);
  const max = Math.max(...values);
  const binWidth = (max - min) / numBins;
  
  const bins = Array.from({ length: numBins }, (_, i) => ({
    x0: min + i * binWidth,
    x1: min + (i + 1) * binWidth,
    count: 0,
    values: []
  }));
  
  values.forEach(value => {
    const binIndex = Math.min(
      Math.floor((value - min) / binWidth),
      numBins - 1
    );
    bins[binIndex].count++;
    bins[binIndex].values.push(value);
  });
  
  return bins;
}

/**
 * Calculate correlation between two numeric variables
 * @param {Array} data - Dataset
 * @param {string} field1 - First field name
 * @param {string} field2 - Second field name
 * @returns {number} Correlation coefficient
 */
export function calculateCorrelation(data, field1, field2) {
  const pairs = data
    .map(row => ({
      x: parseFloat(row[field1]),
      y: parseFloat(row[field2])
    }))
    .filter(p => !isNaN(p.x) && !isNaN(p.y));
  
  if (pairs.length < 2) return 0;
  
  const n = pairs.length;
  const sumX = pairs.reduce((acc, p) => acc + p.x, 0);
  const sumY = pairs.reduce((acc, p) => acc + p.y, 0);
  const sumXY = pairs.reduce((acc, p) => acc + p.x * p.y, 0);
  const sumX2 = pairs.reduce((acc, p) => acc + p.x * p.x, 0);
  const sumY2 = pairs.reduce((acc, p) => acc + p.y * p.y, 0);
  
  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt(
    (n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY)
  );
  
  return denominator === 0 ? 0 : numerator / denominator;
}
