import { useEffect, useRef } from 'react';

/**
 * @param {Function} renderFn - D3 render function that receives the SVG element
 * @param {Array} dependencies - Dependencies array for re-rendering
 * @returns {React.RefObject} Ref to attach to SVG container
 */
export function useD3(renderFn, dependencies = []) {
  const ref = useRef();

  useEffect(() => {
    if (ref.current) {
      renderFn(ref.current);
    }
    
    return () => {
      if (ref.current) {
        while (ref.current.firstChild) {
          ref.current.removeChild(ref.current.firstChild);
        }
      }
    };
  }, dependencies);

  return ref;
}

export default useD3;
