import { motion } from 'framer-motion';
import { TrendingUp, Car, Tag, Activity } from 'lucide-react';

export default function KPICard({ title, value, subtitle, icon, gradient = 'from-primary-500 to-secondary-500' }) {
  // Map icon string to component if needed, or pass component directly
  const IconComponent = typeof icon === 'string' ? null : icon;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      whileHover={{ scale: 1.02, y: -4 }}
      className="glass glass-hover rounded-xl p-6 relative overflow-hidden group border border-slate-100 bg-white"
    >
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <p className="text-sm font-medium text-slate-500 uppercase tracking-wide">{title}</p>
          </div>
          {IconComponent && (
            <div className={`p-2 rounded-lg bg-slate-50 text-primary-600`}>
              <IconComponent size={24} />
            </div>
          )}
        </div>
        
        <div className="space-y-1">
          <h3 className="text-3xl font-bold text-slate-800">
            {value}
          </h3>
          {subtitle && (
            <p className="text-xs text-slate-400">{subtitle}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
