import { motion } from 'framer-motion';

export default function Header({ title, subtitle }) {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="mb-8"
    >
      <h2 className="text-3xl font-bold gradient-text mb-2">{title}</h2>
      {subtitle && (
        <p className="text-gray-400 text-sm">{subtitle}</p>
      )}
    </motion.header>
  );
}
