import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, BarChart2, Activity, TrendingUp, PieChart } from 'lucide-react';

const navItems = [
  { path: '/', label: 'Overview', icon: LayoutDashboard },
  { path: '/histogram', label: 'Distribution', icon: BarChart2 },
  { path: '/scatter', label: 'Scatter Plot', icon: Activity },
  { path: '/timeseries', label: 'Time Series', icon: TrendingUp },
  { path: '/categorical', label: 'Categorical', icon: PieChart },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="w-64 h-screen bg-white border-r border-slate-200 flex flex-col fixed left-0 top-0 z-40 shadow-xl"
    >
      {/* Logo/Title */}
      <div className="p-6 border-b border-slate-100 bg-white/50 backdrop-blur-md">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent flex items-center gap-2">
          <Activity className="text-blue-600" size={28} />
          CarViz
        </h1>
        <p className="text-xs text-slate-500 mt-2 font-medium tracking-wide ml-1">ANALYTICS DASHBOARD</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 mt-4">
        {navItems.map((item, index) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          
          return (
            <Link key={item.path} to={item.path}>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ x: 4, backgroundColor: 'rgba(241, 245, 249, 1)' }}
                className={`
                  flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 group relative overflow-hidden
                  ${isActive 
                    ? 'bg-blue-50 text-blue-700 shadow-sm border border-blue-100' 
                    : 'text-slate-500 hover:text-slate-800'
                  }
                `}
              >
                <Icon size={20} className={`transition-colors duration-200 ${isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-blue-500'}`} />
                <span className="font-medium text-sm tracking-wide">{item.label}</span>
                
                {/* Active Indicator Dot */}
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute right-4 w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]"
                  />
                )}
              </motion.div>
            </Link>
          );
        })}
      </nav>
      
      {/* Decorative Bottom Graphic */}
      <div className="p-6">
        <div className="bg-gradient-to-br from-slate-50 to-white rounded-2xl p-4 border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 rounded-full blur-xl -mr-4 -mt-4"></div>
            <p className="text-xs text-slate-500 font-medium relative z-10">Data updated daily</p>
            <div className="flex items-center gap-2 mt-2">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[10px] text-emerald-600 font-semibold tracking-wider">LIVE SYSTEM</span>
            </div>
        </div>
      </div>
    </motion.aside>
  );
}
