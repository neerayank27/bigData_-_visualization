import { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';
import { useData } from '../../context/DataContext';
import { calculateHistogramBins, calculateStats, calculateCorrelation } from '../../utils/dataAnalyzer';
import { createResponsiveSVG, showTooltip, hideTooltip } from '../../utils/d3Helpers';
import { Activity, BarChart2, TrendingUp } from 'lucide-react';

export default function Histogram({ selectedVariable = null, height = 400 }) {
  const { filteredData, types } = useData();
  // Use filteredData for analysis to respect global filters
  const data = filteredData; 
  const containerRef = useRef();
  const [variable, setVariable] = useState(selectedVariable || 'Price');

  // Compute stats
  const stats = useMemo(() => {
    if (!data || !variable) return null;
    const basicStats = calculateStats(data, variable);
    // Correlation with Price (if variable is not Price)
    let correlation = null;
    if (variable !== 'Price') {
        correlation = calculateCorrelation(data, variable, 'Price');
    }
    return { ...basicStats, correlation };
  }, [data, variable]);

  useEffect(() => {
    if (!data || data.length === 0 || !containerRef.current) return;

    // Clear previous chart
    d3.select(containerRef.current).selectAll('*').remove();

    const margin = { top: 20, right: 30, bottom: 60, left: 70 };
    const { width, innerWidth, innerHeight } = createResponsiveSVG(containerRef.current, margin);

    // Calculate histogram bins
    const bins = calculateHistogramBins(data, variable, 25);
    
    if (bins.length === 0) return;

    // Create SVG
    const svg = d3.select(containerRef.current)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('class', 'overflow-visible');

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Scales
    const xScale = d3.scaleLinear()
      .domain([bins[0].x0, bins[bins.length - 1].x1])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(bins, d => d.count)])
      .nice()
      .range([innerHeight, 0]);

    // Grid lines (Blueish/Light theme)
    g.append('g')
      .attr('class', 'grid')
      .call(d3.axisLeft(yScale).tickSize(-innerWidth).tickFormat(''))
      .selectAll('line').attr('stroke', '#e2e8f0').attr('stroke-dasharray', '3,3');

    // Bars (Solid Blue Theme)
    const bars = g.selectAll('.bar')
      .data(bins)
      .join('rect')
      .attr('class', 'bar')
      .attr('x', d => xScale(d.x0))
      .attr('width', d => Math.max(0, xScale(d.x1) - xScale(d.x0) - 1))
      .attr('y', innerHeight)
      .attr('height', 0)
      .attr('fill', '#3b82f6') // Solid Blue
      .attr('rx', 2)
      .style('cursor', 'pointer');

    // Animate bars
    bars.transition()
      .duration(800)
      .delay((d, i) => i * 20)
      .ease(d3.easeCubicOut)
      .attr('y', d => yScale(d.count))
      .attr('height', d => innerHeight - yScale(d.count));

    // Tooltip
    const tooltip = d3.select(containerRef.current).append('div').attr('class', 'd3-tooltip');

    // Hover effects
    bars
      .on('mouseenter', function(event, d) {
        d3.select(this).transition().duration(150).attr('fill', '#2563eb'); // Darker blue
        const content = `
          <div class="font-semibold mb-1 text-slate-800">${variable}</div>
          <div class="text-sm text-slate-600">Range: ${d.x0.toFixed(1)} - ${d.x1.toFixed(1)}</div>
          <div class="text-sm text-slate-600">Count: <span class="font-bold">${d.count}</span></div>
        `;
        showTooltip(tooltip, content, event);
      })
      .on('mousemove', e => tooltip.style('left', (e.pageX+10)+'px').style('top', (e.pageY-10)+'px'))
      .on('mouseleave', function() {
        d3.select(this).transition().duration(150).attr('fill', '#3b82f6');
        hideTooltip(tooltip);
      });

    // X Axis
    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale).ticks(8))
      .selectAll('text')
      .attr('fill', '#64748b')
      .style('font-size', '11px');

    g.select('.domain').attr('stroke', '#cbd5e1');
    g.selectAll('line').attr('stroke', '#cbd5e1');

    // Y Axis
    g.append('g')
      .call(d3.axisLeft(yScale).ticks(6))
      .selectAll('text')
      .attr('fill', '#64748b')
      .style('font-size', '11px');
      
    g.select('.domain').remove(); // remove y-axis line

    // Axis labels
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 40)
      .attr('text-anchor', 'middle')
      .attr('fill', '#475569')
      .attr('font-size', '13px')
      .attr('font-weight', '500')
      .text(variable);

    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -45)
      .attr('text-anchor', 'middle')
      .attr('fill', '#475569')
      .attr('font-size', '13px')
      .attr('font-weight', '500')
      .text('Frequency');

  }, [data, variable, height]);

  if (!types.numeric || types.numeric.length === 0) {
    return <div className="text-center text-gray-400 py-8">No numeric variables available</div>;
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full space-y-4">
      
      {/* Header and Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-2">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <BarChart2 className="text-blue-500" size={20}/>
            Distribution Analysis
        </h3>
        <select
          value={variable}
          onChange={(e) => setVariable(e.target.value)}
          className="bg-white border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2"
        >
          {types.numeric.map(field => (
            <option key={field} value={field}>{field}</option>
          ))}
        </select>
      </div>

      {/* Stats KPI Mini-Cards */}
      {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-2">
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <span className="text-xs text-blue-600 font-medium block">Mean</span>
                  <span className="text-lg font-bold text-slate-800">{stats.mean.toLocaleString(undefined, {maximumFractionDigits: 1})}</span>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <span className="text-xs text-blue-600 font-medium block">Std Dev</span>
                  <span className="text-lg font-bold text-slate-800">{stats.std.toLocaleString(undefined, {maximumFractionDigits: 1})}</span>
              </div>
               <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <span className="text-xs text-blue-600 font-medium block">Max</span>
                  <span className="text-lg font-bold text-slate-800">{stats.max.toLocaleString()}</span>
              </div>
              {stats.correlation !== null && (
                  <div className="bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                      <span className="text-xs text-indigo-600 font-medium block">Corr. with Price</span>
                      <span className="text-lg font-bold text-slate-800">{stats.correlation.toFixed(3)}</span>
                  </div>
              )}
          </div>
      )}

      <div ref={containerRef} style={{ width: '100%', height: `${height}px` }} className="chart-container" />
    </motion.div>
  );
}
