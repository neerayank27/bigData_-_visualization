import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';
import { useData } from '../../context/DataContext';
import { aggregateByCategory } from '../../utils/dataAnalyzer';
import { createResponsiveSVG, showTooltip, hideTooltip } from '../../utils/d3Helpers';

export default function BarChart({ 
  categoryField = 'Brand', 
  valueField = null, 
  height = 400,
  maxBars = 15,
  orientation = 'vertical',
  data: propData = null, // Allow passing custom data
  onBarClick = null, // Callback for clicks
  title = ''
}) {
  const { data: contextData } = useData();
  const data = propData || contextData;
  const containerRef = useRef();

  useEffect(() => {
    if (!data || data.length === 0 || !containerRef.current) return;

    // Clear previous chart
    d3.select(containerRef.current).selectAll('*').remove();

    const margin = orientation === 'vertical' 
      ? { top: 20, right: 30, bottom: 80, left: 60 }
      : { top: 20, right: 60, bottom: 40, left: 150 };
    
    const { width, innerWidth, innerHeight } = createResponsiveSVG(containerRef.current, margin);

    // Aggregate data if not already aggregated
    // If propData is passed, assume it might already be prepared, BUT for now 
    // let's assume we always pass raw data and aggregate it here, 
    // OR if "data" is prep-aggregated (has 'category' and 'count'), use it.
    let aggregated;
    
    if (propData && propData.length > 0 && 'category' in propData[0]) {
      // Pre-aggregated
       aggregated = propData.slice(0, maxBars);
    } else {
       aggregated = aggregateByCategory(data, categoryField, valueField)
        .slice(0, maxBars);
    }
    
    if (aggregated.length === 0) return;

    // Create SVG
    const svg = d3.select(containerRef.current)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('class', 'overflow-visible');

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Determine value to display
    const getValue = d => valueField ? (d.average || d.total || 0) : (d.count || d.value);

    // Color scale for light theme blue-ish
    const colorScale = d3.scaleSequential()
        .domain([0, aggregated.length])
        .interpolator(d3.interpolateBlues);

    if (orientation === 'vertical') {
      const xScale = d3.scaleBand()
        .domain(aggregated.map(d => d.category))
        .range([0, innerWidth])
        .padding(0.3);

      const yScale = d3.scaleLinear()
        .domain([0, d3.max(aggregated, getValue)])
        .nice()
        .range([innerHeight, 0]);

      // Grid
      g.append('g')
        .attr('class', 'grid')
        .call(d3.axisLeft(yScale).tickSize(-innerWidth).tickFormat(''))
        .selectAll('line').attr('stroke', '#e2e8f0').attr('stroke-dasharray', '3,3');

      // Tooltip
      const tooltip = d3.select(containerRef.current).append('div').attr('class', 'd3-tooltip');

      // Bars
      const bars = g.selectAll('.bar')
        .data(aggregated)
        .join('rect')
        .attr('class', 'bar')
        .attr('x', d => xScale(d.category))
        .attr('width', xScale.bandwidth())
        .attr('y', innerHeight)
        .attr('height', 0)
        .attr('fill', '#3b82f6')
        .attr('rx', 4)
        .style('cursor', onBarClick ? 'pointer' : 'default');

      bars.transition().duration(800).delay((d, i) => i * 30).ease(d3.easeCubicOut)
        .attr('y', d => yScale(getValue(d)))
        .attr('height', d => innerHeight - yScale(getValue(d)));

      bars
        .on('mouseenter', function(event, d) {
           d3.select(this).attr('fill', '#2563eb');
           const content = `
             <div class="font-semibold text-slate-800">${d.category}</div>
             <div class="text-sm text-slate-600">Count: <span class="font-bold">${d.count}</span></div>
           `;
           showTooltip(tooltip, content, event);
        })
        .on('mousemove', e => tooltip.style('left', (e.pageX+10)+'px').style('top', (e.pageY-10)+'px'))
        .on('mouseleave', function() {
           d3.select(this).attr('fill', '#3b82f6');
           hideTooltip(tooltip);
        })
        .on('click', (event, d) => {
           if (onBarClick) onBarClick(d.category);
        });

      // Axis
      g.append('g').attr('transform', `translate(0,${innerHeight})`)
        .call(d3.axisBottom(xScale))
        .selectAll('text')
        .attr('transform', 'rotate(-45)')
        .style('text-anchor', 'end')
        .style('fill', '#64748b');

      g.append('g').call(d3.axisLeft(yScale).ticks(5)).style('color', '#64748b');

    } else {
        // Horizontal implementation similar update if needed, but focusing on Vertical for now as primary
        // Keeping basic structure for safety but simplifying heavily
        const xScale = d3.scaleLinear()
        .domain([0, d3.max(aggregated, getValue)])
        .range([0, innerWidth]);

        const yScale = d3.scaleBand()
        .domain(aggregated.map(d => d.category))
        .range([0, innerHeight])
        .padding(0.3);
        
        const bars = g.selectAll('.bar')
        .data(aggregated)
        .join('rect')
        .attr('class', 'bar')
        .attr('y', d => yScale(d.category))
        .attr('height', yScale.bandwidth())
        .attr('x', 0)
        .attr('width', d => xScale(getValue(d)))
        .attr('fill', '#3b82f6')
        .attr('rx', 4);
        
        g.append('g').attr('transform', `translate(0,${innerHeight})`).call(d3.axisBottom(xScale));
        g.append('g').call(d3.axisLeft(yScale));
    }

  }, [data, categoryField, valueField, height, maxBars, orientation, propData, onBarClick]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full">
      {title && <h4 className="text-md font-semibold text-slate-700 mb-2">{title}</h4>}
      <div ref={containerRef} style={{ width: '100%', height: `${height}px` }} className="chart-container" />
    </motion.div>
  );
}
