import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';
import { useData } from '../../context/DataContext';
import { aggregateByDate } from '../../utils/dataAnalyzer';
import { createResponsiveSVG, showTooltip, hideTooltip } from '../../utils/d3Helpers';

export default function TimeSeriesScatter({ dateField = 'Date', valueField = 'Price', height = 450 }) {
  const { filteredData, types } = useData();
  const containerRef = useRef();

  useEffect(() => {
    if (!filteredData || filteredData.length === 0 || !containerRef.current) return;

    // Prioritize prop 'dateField'
    const actualDateField = (types.date && types.date.includes(dateField)) ? dateField : (types.date && types.date.length > 0 ? types.date[0] : dateField);
    
    // Clear previous chart
    d3.select(containerRef.current).selectAll('*').remove();

    const margin = { top: 40, right: 30, bottom: 80, left: 60 };
    const { width, innerWidth, innerHeight } = createResponsiveSVG(containerRef.current, margin);

    // Aggregate data by DATE (Daily)
    const aggregated = aggregateByDate(filteredData, actualDateField, valueField);
    
    if (aggregated.length === 0) {
      d3.select(containerRef.current).append('div').text('No data available');
      return;
    }

    // Create SVG
    const svg = d3.select(containerRef.current)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('class', 'overflow-visible');

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Title
    svg.append('text')
        .attr('x', width / 2)
        .attr('y', 20)
        .attr('text-anchor', 'middle')
        .attr('class', 'text-sm font-semibold fill-slate-700')
        .style('font-size', '16px')
        .text('Average Car Price Over Time');

    // Scales
    const xScale = d3.scaleTime()
      .domain(d3.extent(aggregated, d => d.date))
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([d3.min(aggregated, d => d.average) * 0.95, d3.max(aggregated, d => d.average) * 1.05])
      .nice()
      .range([innerHeight, 0]);

    // Grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(d3.axisLeft(yScale).tickSize(-innerWidth).tickFormat(''))
      .selectAll('line').attr('stroke', '#e2e8f0').attr('stroke-dasharray', '3,3');
      
    g.append('g')
      .attr('class', 'grid')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale).tickSize(-innerHeight).tickFormat(''))
      .selectAll('line').attr('stroke', '#e2e8f0').attr('stroke-dasharray', '3,3');

    // Tooltip
    const tooltip = d3.select(containerRef.current).append('div').attr('class', 'd3-tooltip');

    // Points (Scatter style as per image)
    const points = g.selectAll('.point')
      .data(aggregated)
      .join('circle')
      .attr('class', 'point')
      .attr('cx', d => xScale(d.date))
      .attr('cy', d => yScale(d.average))
      .attr('r', 5)
      .attr('fill', '#4f46e5') // Indigo/Blueish like the reference
      .attr('opacity', 0.8)
      .attr('stroke', '#fff')
      .attr('stroke-width', 1)
      .style('cursor', 'pointer');

    points
      .on('mouseenter', function(event, d) {
        d3.select(this).transition().duration(150).attr('r', 7).attr('fill', '#2563eb').attr('opacity', 1);
        const content = `
          <div class="font-bold text-slate-800">${d3.timeFormat('%Y-%m-%d')(d.date)}</div>
          <div class="text-sm text-slate-600">Avg: <span class="font-bold">${d.average.toLocaleString(undefined, {style:'currency', currency:'LKR', maximumFractionDigits:0})}</span></div>
        `;
        showTooltip(tooltip, content, event);
      })
      .on('mousemove', e => tooltip.style('left', (e.pageX+10)+'px').style('top', (e.pageY-10)+'px'))
      .on('mouseleave', function() {
        d3.select(this).transition().duration(150).attr('r', 5).attr('fill', '#1f15daff').attr('opacity', 0.8);
        hideTooltip(tooltip);
      });

    // Axes
    const xAxis = g.append('g').attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale)
        .ticks(10) // Approx number of ticks
        .tickFormat(d3.timeFormat('%Y-%m-%d'))
      );
    
    xAxis.selectAll('text')
        .style('fill', '#1e293b')
        .style('font-size', '10px')
        .attr('transform', 'rotate(-45)')
        .style('text-anchor', 'end')
        .attr('dx', '-0.8em')
        .attr('dy', '0.15em');
        
    xAxis.selectAll('path, line').style('stroke', '#94a3b8');

    const yAxis = g.append('g').call(d3.axisLeft(yScale).ticks(8));
    yAxis.selectAll('text').style('fill', '#1e293b').style('font-size', '10px');
    yAxis.selectAll('path, line').style('stroke', '#94a3b8');

    // Labels
    g.append('text').attr('x', innerWidth/2).attr('y', innerHeight + 65).attr('text-anchor', 'middle').attr('fill', '#1e293b').style('font-size', '12px').text('Date');
    g.append('text').attr('transform', 'rotate(-90)').attr('x', -innerHeight/2).attr('y', -45).attr('text-anchor', 'middle').attr('fill', '#1e293b').style('font-size', '12px').text('Average Price');

  }, [filteredData, dateField, valueField, height, types]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full bg-white rounded-lg">
      <div ref={containerRef} style={{ width: '100%', height: `${height}px` }} className="chart-container" />
    </motion.div>
  );
}
