import { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';
import { useData } from '../../context/DataContext';
import { createResponsiveSVG, showTooltip, hideTooltip } from '../../utils/d3Helpers';

export default function ScatterPlot({ height = 500 }) {
  const { filteredData, types } = useData(); // Use filteredData
  const containerRef = useRef();
  
  // Hardcoded as requested
  const xVariable = 'Vehicle_Age';
  const yVariable = 'Price';

  useEffect(() => {
    if (!filteredData || filteredData.length === 0 || !containerRef.current) return;

    // Clear previous chart
    d3.select(containerRef.current).selectAll('*').remove();

    const margin = { top: 20, right: 30, bottom: 60, left: 80 };
    const { width, innerWidth, innerHeight } = createResponsiveSVG(containerRef.current, margin);

    // Filter valid data points
    const validData = filteredData
      .map(d => ({
        x: parseFloat(d[xVariable]),
        y: parseFloat(d[yVariable]),
        original: d
      }))
      .filter(d => !isNaN(d.x) && !isNaN(d.y));

    if (validData.length === 0) {
       d3.select(containerRef.current).append('div').text('No data available for current filters');
       return;
    }

    // Create SVG
    const svg = d3.select(containerRef.current)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('class', 'overflow-visible');

    // ... (Scales and rendering logic similar to before, but simplified for fixed axes)
    // For brevity, I'm keeping the core logic but removing the dropdowns from JSX
    
    // ... Copying core D3 logic ...
    
    const xScale = d3.scaleLinear()
      .domain([0, d3.max(validData, d => d.x) || 10]).nice() // Start from 0 for Age
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(validData, d => d.y) || 1000]).nice()
      .range([innerHeight, 0]);

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // Axes
    const xAxis = d3.axisBottom(xScale);
    const yAxis = d3.axisLeft(yScale).tickFormat(d => d >= 1000 ? `${d/1000}k` : d);

    g.append('g').attr('transform', `translate(0,${innerHeight})`).call(xAxis);
    g.append('g').call(yAxis);

    // Labels
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 40)
      .attr('text-anchor', 'middle')
      .attr('fill', '#64748b')
      .text('Vehicle Age (Years)');

    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -60)
      .attr('text-anchor', 'middle')
      .attr('fill', '#64748b')
      .text('Price (LKR)');

    // Points
    g.selectAll('circle')
      .data(validData)
      .join('circle')
      .attr('cx', d => xScale(d.x))
      .attr('cy', d => yScale(d.y))
      .attr('r', 4)
      .attr('fill', 'rgba(59, 130, 246, 0.6)') // Primary blue transparency
      .attr('stroke', '#2563eb')
      .style('cursor', 'pointer')
      .on('mouseover', function(event, d) {
          d3.select(this).attr('r', 6).attr('fill', '#0ea5e9');
          const content = `
            <div class="font-bold">Price: ${d.original.Price?.toLocaleString()} LKR</div>
            <div>Age: ${d.x} years</div>
          `;
          showTooltip(d3.select('.d3-tooltip'), content, event);
      })
      .on('mouseout', function() {
          d3.select(this).attr('r', 4).attr('fill', 'rgba(59, 130, 246, 0.6)');
          hideTooltip(d3.select('.d3-tooltip'));
      });

  }, [filteredData, height]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full">
      <div className="mb-2">
        <h3 className="text-lg font-semibold text-gray-800">Price vs Vehicle Age</h3>
      </div>
      <div ref={containerRef} style={{ width: '100%', height: `${height}px` }} className="chart-container" />
    </motion.div>
  );
}
