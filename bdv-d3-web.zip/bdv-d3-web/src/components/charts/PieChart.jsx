import { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { motion } from 'framer-motion';
import { useData } from '../../context/DataContext';
import { aggregateByCategory } from '../../utils/dataAnalyzer';
import { createResponsiveSVG, showTooltip, hideTooltip } from '../../utils/d3Helpers';
import { Filter, ArrowUp, ArrowDown } from 'lucide-react';

export default function PieChart({ 
  categoryField = 'Brand', 
  valueField = null, // if null, uses count
  height = 400,
  title = '',
  maxSlices = 10,
  onSliceClick = null
}) {
  const { data: contextData, filteredData } = useData();
  // Use filteredData if available so it responds to global filters, unless specifically designed otherwise
  const data = filteredData || contextData;
  
  const containerRef = useRef();
  const [sortMode, setSortMode] = useState('valueDesc'); // valueDesc, valueAsc, nameAsc

  // Aggregate Data
  const aggregatedData = useMemo(() => {
    if (!data) return [];
    
    // Aggregate
    let agg = aggregateByCategory(data, categoryField, valueField);
    
    // Sort
    if (sortMode === 'valueDesc') {
        agg.sort((a, b) => (valueField ? b.total - a.total : b.count - a.count));
    } else if (sortMode === 'valueAsc') {
        agg.sort((a, b) => (valueField ? a.total - b.total : a.count - b.count));
    } else if (sortMode === 'nameAsc') {
        agg.sort((a, b) => a.category.localeCompare(b.category));
    }

    // Limit slices for Pie Chart readability, group others
    if (agg.length > maxSlices) {
        const top = agg.slice(0, maxSlices);
        const others = agg.slice(maxSlices);
        const otherCount = others.reduce((acc, curr) => acc + curr.count, 0);
        // "Other" entry
        if (otherCount > 0) {
            top.push({ category: 'Others', count: otherCount, isOther: true });
        }
        return top;
    }

    return agg;
  }, [data, categoryField, valueField, sortMode, maxSlices]);

  useEffect(() => {
    if (!aggregatedData || aggregatedData.length === 0 || !containerRef.current) return;

    // Clear
    d3.select(containerRef.current).selectAll('*').remove();

    const margin = { top: 20, right: 120, bottom: 20, left: 20 }; // Huge right margin for legend
    const { width, innerWidth, innerHeight } = createResponsiveSVG(containerRef.current, margin);
    
    const radius = Math.min(innerWidth, innerHeight) / 2;

    const svg = d3.select(containerRef.current)
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('class', 'overflow-visible');
      
    const g = svg.append('g')
      .attr('transform', `translate(${width/2 - 50},${height/2})`); // Offset left slightly to make room for legend

    // Center Text Group
    const centerText = g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '-0.5em')
      .style('pointer-events', 'none')
      .style('opacity', 0);
      
    centerText.append('tspan')
      .attr('class', 'center-label')
      .attr('x', 0)
      .attr('dy', '0')
      .style('font-size', '14px')
      .style('fill', '#64748b')
      .style('font-weight', '500');

    centerText.append('tspan')
      .attr('class', 'center-value')
      .attr('x', 0)
      .attr('dy', '1.4em')
      .style('font-size', '20px')
      .style('fill', '#1e293b')
      .style('font-weight', 'bold');
      
    centerText.append('tspan')
      .attr('class', 'center-percent')
      .attr('x', 0)
      .attr('dy', '1.4em')
      .style('font-size', '12px')
      .style('fill', '#64748b');

    const getValue = d => valueField ? (d.total || d.average) : d.count;

    // Color Scale
    // Color Scale - Safe fallback
    const colors = d3.quantize(d3.interpolateSpectral, Math.max(3, aggregatedData.length));
    const colorScale = d3.scaleOrdinal()
        .domain(aggregatedData.map(d => d.category))
        .range(colors);

    // Pie Generator
    const pie = d3.pie()
      .value(d => getValue(d))
      .sort(null); // Already sorted

    // Arc Generator
    const arc = d3.arc()
      .innerRadius(radius * 0.5) // Donut style
      .outerRadius(radius * 0.9);
      
    const arcHover = d3.arc()
      .innerRadius(radius * 0.5)
      .outerRadius(radius * 0.95);

    const tooltip = d3.select(containerRef.current).append('div').attr('class', 'd3-tooltip');

    // Draw Slices
    const paths = g.selectAll('path')
      .data(pie(aggregatedData))
      .join('path')
      .attr('d', arc)
      .attr('fill', d => d.data.isOther ? '#cbd5e1' : colorScale(d.data.category)) // Grey for 'Others'
      .attr('stroke', 'white')
      .style('stroke-width', '2px')
      .style('cursor', 'pointer')
      .style('opacity', 0.9);

    // Transitions
    paths.transition()
        .duration(750)
        .attrTween('d', function(d) {
            const i = d3.interpolate(d.startAngle+0.1, d.endAngle);
            return function(t) {
                d.endAngle = i(t);
                return arc(d);
            }
        });

    // Interactions
    paths
      .on('mouseenter', function(event, d) {
        d3.select(this)
          .transition().duration(200)
          .attr('d', arcHover)
          .style('opacity', 1)
          .style('filter', 'drop-shadow(0px 3px 6px rgba(0,0,0,0.2))');
          
        const val = getValue(d.data);
        const percent = ((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100;
        
        const content = `
          <div class="font-bold text-slate-800">${d.data.category}</div>
          <div class="text-sm text-slate-600">
             Count: <span class="font-bold">${val.toLocaleString()}</span>
          </div>
          <div class="text-xs text-slate-500 mt-1">${percent.toFixed(1)}% of total</div>
        `;
        showTooltip(tooltip, content, event);

        // Update Center Text
        centerText.select('.center-label').text(d.data.category);
        centerText.select('.center-value').text(val.toLocaleString());
        centerText.select('.center-percent').text(`${percent.toFixed(1)}%`);
        centerText.transition().duration(200).style('opacity', 1);
      })
      .on('mousemove', e => tooltip.style('left', (e.pageX+10)+'px').style('top', (e.pageY-10)+'px'))
      .on('mouseleave', function() {
         d3.select(this)
           .transition().duration(200)
           .attr('d', arc)
           .style('opacity', 0.9)
           .style('filter', 'none');
         hideTooltip(tooltip);
         
         // Hide Center Text
         centerText.transition().duration(200).style('opacity', 0);
      })
      .on('click', (event, d) => {
         if (onSliceClick && !d.data.isOther) onSliceClick(d.data.category);
      });

    // Legend
    const legendG = svg.append('g')
      .attr('transform', `translate(${width - 100}, 20)`); // Top right

    aggregatedData.forEach((d, i) => {
        const row = legendG.append('g').attr('transform', `translate(0, ${i * 20})`);
        
        row.append('rect')
           .attr('width', 10)
           .attr('height', 10)
           .attr('rx', 2)
           .attr('fill', d.isOther ? '#cbd5e1' : colorScale(d.category));
           
        row.append('text')
           .attr('x', 15)
           .attr('y', 9)
           .text(d.category)
           .style('font-size', '11px')
           .style('fill', '#475569')
           .style('cursor', 'default');
    });

  }, [aggregatedData, height, valueField]);

  return (
    <div className="w-full h-full relative">
      <div className="flex items-center justify-between mb-2">
         {title && <h4 className="text-md font-semibold text-slate-700">{title}</h4>}
         
         {/* Sorting Controls */}
         <div className="flex bg-slate-100 rounded-lg p-1 gap-1">
            <button 
              onClick={() => setSortMode('valueDesc')}
              className={`p-1.5 rounded-md transition-colors ${sortMode === 'valueDesc' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
              title="Sort by Value (Desc)"
            >
              <ArrowDown size={14} className=""/>
            </button>
            <button 
               onClick={() => setSortMode('valueAsc')}
               className={`p-1.5 rounded-md transition-colors ${sortMode === 'valueAsc' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
               title="Sort by Value (Asc)"
            >
              <ArrowUp size={14}/>
            </button>
            <button 
               onClick={() => setSortMode('nameAsc')}
               className={`p-1.5 rounded-md transition-colors ${sortMode === 'nameAsc' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
               title="Sort by Name"
            >
              <Filter size={14}/>
            </button>
         </div>
      </div>
      <div ref={containerRef} style={{ width: '100%', height: `${height}px` }} className="chart-container" />
    </div>
  );
}
