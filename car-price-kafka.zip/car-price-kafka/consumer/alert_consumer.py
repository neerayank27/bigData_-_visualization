from kafka import KafkaConsumer
import json, logging

logging.basicConfig(filename="pipeline.log", level=logging.INFO)

consumer = KafkaConsumer(
    "car_prices",
    bootstrap_servers="localhost:9092",
    group_id="alert-group",
    value_deserializer=lambda x: json.loads(x.decode("utf-8"))
)

print("Alert consumer running...")

for msg in consumer:
    data = msg.value
    price = data["price"]

    alert_info = f"""
Vehicle Alert
Brand: {data['brand']}
Model: {data['model']}
Year: {data['yom']}
Price: {price}
"""

    if price > 600:
        print("HIGH PRICE ALERT:", alert_info)
    elif price < 10:
        print("LOW PRICE ALERT:", alert_info)
    else:
        print("PRICE WITHIN RANGE:", data["brand"], data["model"], price)
