from flask import Flask, render_template, jsonify
import sqlite3
import os
import statistics

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "car_stream.db")


def fetch_all():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT brand, model, yom, vehice_age, mileage, price
        FROM car_prices
    """)
    rows = cursor.fetchall()

    conn.close()
    return rows


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/summary")
def summary():
    rows = fetch_all()

    if not rows:
        return jsonify({
            "total_listings": 0,
            "average_price": 0,
            "median_price": 0,
            "avg_price_by_brand": {},
            "records": []
        })

    prices = [r[5] for r in rows]

    brand_avg = {}
    for r in rows:
        brand_avg.setdefault(r[0], []).append(r[5])

    return jsonify({
        "total_listings": len(prices),
        "average_price": int(sum(prices) / len(prices)),
        "median_price": int(statistics.median(prices)),
        "avg_price_by_brand": {
            k: int(sum(v) / len(v)) for k, v in brand_avg.items()
        },
        "records": [
            {
                "brand": r[0],
                "model": r[1],
                "yom": r[2],
                "age": r[3],
                "mileage": r[4],
                "price": r[5]
            } for r in rows
        ]
    })


if __name__ == "__main__":
    app.run(debug=True)
