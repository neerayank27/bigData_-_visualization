async function loadData() {
    const res = await fetch("/api/summary");
    return await res.json();
}

function histogram(values, bins = 8) {
    const min = Math.min(...values);
    const max = Math.max(...values);
    const step = Math.ceil((max - min) / bins);

    let labels = [], counts = Array(bins).fill(0);

    values.forEach(v => {
        let i = Math.min(Math.floor((v - min) / step), bins - 1);
        counts[i]++;
    });

    for (let i = 0; i < bins; i++) {
        labels.push(`${min + i*step} - ${min + (i+1)*step}`);
    }

    return { labels, counts };
}

async function render() {
    const data = await loadData();

    document.getElementById("total").innerText = data.total_listings;
    document.getElementById("avg").innerText = data.average_price;
    document.getElementById("median").innerText = data.median_price;

    const prices = data.records.map(r => r.price);
    const hist = histogram(prices);

    new Chart(histChart, {
        type: "bar",
        data: {
            labels: hist.labels,
            datasets: [{ data: hist.counts }]
        }
    });

    new Chart(scatterChart, {
        type: "scatter",
        data: {
            datasets: [{
                data: data.records.map(r => ({ x: r.age, y: r.price }))
            }]
        }
    });

    new Chart(brandChart, {
        type: "bar",
        data: {
            labels: Object.keys(data.avg_price_by_brand),
            datasets: [{
                data: Object.values(data.avg_price_by_brand)
            }]
        }
    });

    const tbody = document.querySelector("#dataTable tbody");
    data.records.slice(0, 20).forEach(r => {
        tbody.innerHTML += `
            <tr>
                <td>${r.brand}</td>
                <td>${r.model}</td>
                <td>${r.yom}</td>
                <td>${r.age}</td>
                <td>${r.mileage}</td>
                <td>${r.price}</td>
            </tr>`;
    });
}

render();
