import json, time, logging
import pandas as pd
from kafka import KafkaProducer

logging.basicConfig(filename="pipeline.log", level=logging.INFO)

# Load CSV
df = pd.read_csv("data/car_price_cleaned.csv")

# Normalize column names
df.columns = df.columns.str.strip().str.lower()

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

print("Producing car listing events...")

for _, row in df.iterrows():
    event = {
        "vehicle_id": str(row["vehicle_id"]),
        "brand": row["brand"],
        "model": row["model"],
        "yom": int(row["yom"]),
        "vehice_age": int(row["vehice_age"]),
        "engine_cc": int(row["engine_cc"]),
        "mileage": int(row["mileage"]),
        "price": int(row["price"]),
        "date": str(row["date"])
    }

    producer.send("car_prices", value=event)
    print("Produced:", event)
    time.sleep(1)

producer.flush()
print("All car listing events produced.")